# -------------------------------------------------#
# Title: Working with Dictionaries
# Dev:   RRoot
# Date:  July 16, 2012
# ChangeLog: (Who, When, What)
#   RRoot, 11/02/2016, Created starting template
#   <Sharon Collier>,04/27/2018, Added code to complete assignment 5
#  <Sharon Collier>,05/06/2018, Added code to complete assignment 6


# -------------------------------------------------#

# -- Data --#
# declare variables and constants


# objFile = An object that represents a file
# strData = A row of text data from the file
# dicRow = A row of data separated into elements of a dictionary {Task,Priority}
# lstTable = A dictionary that acts as a 'table' of rows
# strMenu = A menu of user options
# strChoice = Capture the user option selection

# -- Input/Output --#
# User can see a Menu (Step 2)
# User can see data (Step 3)
# User can insert or delete data(Step 4 and 5)
# User can save to file (Step 6)

# -- Processing --#
# Step 1
# When the program starts, load the any data you have
# in a text file called ToDo.txt into a python Dictionary.

# Step 2
# Display a menu of choices to the user

# Step 3
# Display all todo items to user

# Step 4
# Add a new item to the list/Table

# Step 5
# Remove a new item to the list/Table

# Step 6
# Save tasks to the ToDo.txt file

# Step 7
# Exit program
# Step 1 - Load data from a file
# When the program starts, load each "row" of data
# in "ToDo.txt" into a python Dictionary.
# Add the each dictionary "row" to a python list "table"


# -------------------------------
#data
objFileName = "C:\_PythonClass\ToDo"
strData = ""
dicRow = {}
strTask = ""
Priority = ""

lstTable = []
print(lstTable)


#Processing Code

class MenuofOptions():

    @staticmethod
    def Menu():#Menu of Options shown to user
        print("""
           *~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~
           Menu of Options
           1) Show current data
           2) Add a new item.
           3) Remove an existing item.
           4) Save Data to File
           5) Exit Program
           *~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~
           """)

    @staticmethod
    def OptionOne(self):#show current data
        print("Your current list so far", lstTable )
        return print("the last to-do entered:", dicRow )

    @staticmethod
    def OptionTwo(self): #Add a new item
        strTask = input("To Do:")
        if strTask not in lstTable:
            Priority = input("What is the priority? High or Low?")
            dicRow[strTask] = Priority
            lstTable.append ( dicRow )
            print("\n", strTask, "has been added! Good luck!")
        else:
            print ( "\nThat item is already on the list!" )

    @staticmethod
    def OptionThree(self): #remove an existing item
        strTask = input ( "what would you like to delete?" )
        if strTask in dicRow:
            del dicRow[strTask]
        else:
            print ( "I am sorry, that doesn't seem to be on your list. Lucky you!" )
        print ( "But don't forget to do this:" , dicRow )

    @staticmethod
    def OptionFour(self):#save data to file
        objF = open("C:\\_PythonClass\\ToDo.txt", "a")
        for row in lstTable:
            objF.write ( str ( lstTable ) )
        objF.close ()
        print("Ok, Data\n\r", lstTable, " Saved!")

    @staticmethod
    def OptionFive(self):#exit
        print("Ok, Bye!")
        break 



# Step 2 - Display a menu of choices to the user
#presentation (i/o) code
while (True):
    MenuofOptions.Menu()

    strChoice = str ( input ( "Which option would you like to perform? [1 to 4] - " ) )
    print ()  # adding a new line

    # Step 3 -Show the current items in the table
    if (strChoice.strip () == '1'):#Show Data
        MenuofOptions.OptionOne()
        continue
    # Step 4 - Add a new item to the list/Table

    elif (strChoice.strip () == '2'):#Add a New Item
        MenuofOptions.OptionTwo()
        continue

    # Step 5 - Remove a new item to the list/Table
    elif (strChoice == '3'):#Remove an existing item
        MenuofOptions.OptionThree()
        continue

    # Step 6 - Save tasks to the ToDo.txt file
    elif (strChoice == '4'):#Save Data to File
        MenuofOptions.OptionFour()
        continue


    elif (strChoice == '5'):#Exit Program
        MenuofOptions.OptionFive()
        break

        # and Exit the program