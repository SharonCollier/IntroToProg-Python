#Create an application that uses a list to hold the following data
'''
Id	Name	Email
1	Bob Smith	BSmith@Hotmail.com
2	Sue Jones	SueJ@Yahoo.com
3	Joe James	JoeJames@Gmail.com

2)	Add code that lets users appends a new row of data.
3)	Add a loop that lets the user keep adding rows.
4)	Ask the user if they want to save the data to a file when they exit the loop.
5)	Save the data to a file if they say 'yes'

'''

MembershipHeader = ["ID", "Name", "Email" ]
lstRow0 = [1, "Bob Smith", "BSmith@Hotmail.com" ]
lstRow1 = [2, "Sue Jones", "SueJ@yahoo.com" ]
lstRow2 = [3, "Joe James", "JoeJames@gmail.com" ]
lstTable = [MembershipHeader, lstRow0, lstRow1, lstRow2]
print(lstTable)

while(True):
    intID = int(input("Enter an ID: "))
    strName = input("Enter a name: ")
    strEmail = input("Enter an Email: ")
    lstNewRow = [intID, strName, strEmail]
    lstTable.append(lstNewRow)
    print(lstTable)
    if input("Type exit to end").lower()==  ("exit"):break
print(lstTable)

strSaveToFile = input("Would you like to save? (y/n)")
if (strSaveToFile.lower() == 'y'):
    objF = open("Lab05Data.txt" , "a")
    for row in lstTable:
        objF.write(str(lstTable))
    objF.close()
    print("Ok, Data\n\r", lstTable, " Saved!")
else:
    print("Data not saved")
#if input("Type Exit to end: ").lower() == "exit": break